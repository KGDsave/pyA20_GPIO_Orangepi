# orangepi_ZERO_gpio_pyH2+
python control orangepi_ZERO ext GPIO ALLwinner H2+ base on pyA20 0.2.1

open source modified base on orangepi_PC_gpio_pyH3

reference https://www.olimex.com/wiki/A20-OLinuXino-MICRO pyA20 https://pypi.python.org/pypi/pyA20

install ::

python setup.py install 


blink_led_test:

![img](https://github.com/wdmomoxx/orangepi_ZERO_gpio_pyH2/blob/master/blink_led_test.png)
